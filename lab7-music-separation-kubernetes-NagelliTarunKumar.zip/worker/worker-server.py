import os
import redis
import json
import base64
import requests
import time
from minio import Minio
import subprocess

# Initialize Redis, MinIO, and log settings
print("Attempting to connect to Redis at", os.getenv("REDIS_HOST", "redis"))
try:
    redis_client = redis.StrictRedis(host=os.getenv("REDIS_HOST", "redis"), port=6379, db=0)
    redis_client = redis.StrictRedis(host="localhost", port=6379, db=0)
    redis_client.ping()
    print("Successfully connected to Redis.")
except redis.ConnectionError:
    print("Failed to connect to Redis.")


try:
    minio_client = Minio(
        # os.getenv("MINIO_ENDPOINT", "minio-proj.minio-ns.svc.cluster.local:9000"),
        "localhost:9000",
        access_key=os.getenv("MINIO_ACCESS_KEY", "rootuser"),
        secret_key=os.getenv("MINIO_SECRET_KEY", "rootpass123"),
        secure=False,
    )
    if minio_client.bucket_exists("output"):
        print("Successfully connected to MinIO and verified the 'output' bucket.")
    else:
        print("MinIO is reachable, but 'output' bucket does not exist.")
        minio_client.make_bucket("output")
        print("Successfully created bucket")
except Exception as e:
    print(f"Failed to connect to MinIO: {e}")

def process_song(songhash, mp3_data):
    try:
        print(f"Processing song with hash: {songhash}")
        input_path = f"/tmp/{songhash}.mp3"
        output_dir = f"/tmp/output/htdemucs/{songhash}"

        # Decode base64 data and write to file
        try:
            decoded_data = base64.b64decode(mp3_data)
            with open(input_path, "wb") as f:
                f.write(decoded_data)
        except base64.binascii.Error as decode_error:
            print(f"Error decoding base64 for {songhash}: {decode_error}")
            return

        # decoded_data = mp3_data

        # Run DEMUCS to separate audio
        print(f"Running DEMUCS on {input_path}...")
        demucs_command = f"python3 -m demucs.separate --mp3 --out /tmp/output {input_path}"
        process = subprocess.run(demucs_command, shell=True, text=True)
        
        # Check if DEMUCS command was successful
        if process.returncode != 0:
            print(f"DEMUCS failed for {songhash} with return code {process.returncode}")
            return

        # Upload separated tracks to MinIO
        for part in ["bass", "drums", "vocals", "other"]:
            part_path = f"{output_dir}/{part}.mp3"
            if os.path.exists(part_path):
                print(f"Uploading {part} track for {songhash} to MinIO")
                minio_client.fput_object("output", f"{songhash}/{part}.wav", part_path)
            else:
                print(f"Warning: {part_path} does not exist for {songhash}")

    except Exception as e:
        print(f"Error in process_song for {songhash}: {e}")

def listen_to_queue():
    callback_base_url = "http://rest.default.svc.cluster.local:80"
    print("Starting to listen to the Redis queue...")
    while True:
        try:
            print("Waiting for a new task...")
            result = redis_client.blpop("toWorkers", timeout=10)

            if result is None:
                print("No task received, continue waiting...")
                continue

            _, message = result
            string_message = message.decode("utf-8")
            print("Raw message from Redis:", string_message)
            
            data = json.loads(string_message)
            
            if 'mp3' not in data or 'songhash' not in data:
                print("Error: Task missing 'mp3' or 'songhash' field.")
                print("Received data structure:", data)
                continue

            songhash = data["songhash"]
            mp3_data = data["mp3"]
            print(f"Received task for songhash: {songhash}")

            # Process the song using DEMUCS
            process_song(songhash, mp3_data)

            if "callback" in data and "url" in data["callback"]:
                # 如果 `data["callback"]["url"]` 中包含 `localhost`，替換成 `rest-service`
                callback_url = (
                    data["callback"]["url"].replace("localhost", "rest-service")
                    if data["callback"]["url"].startswith("http")
                    else f"{callback_base_url}{data['callback']['url']}"
                )
                callback_data = data["callback"]["data"]
                print(f"Sending callback for {songhash} to {callback_url} with data: {callback_data}")
                try:
                    response = requests.post(callback_url, json=callback_data)
                    if response.status_code != 200:
                        print(f"Callback failed with status {response.status_code}: {response.text}")
                except requests.exceptions.RequestException as e:
                    print(f"Error sending callback: {e}")



            time.sleep(2)

        except Exception as e:
            print(f"Error processing task: {e}")
            time.sleep(5)

if __name__ == "__main__":
    print("Worker started, listening to Redis queue...")
    listen_to_queue()
